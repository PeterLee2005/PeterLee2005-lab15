
public class EnigmaGUI {
    public static void main (String args[]) {
        EnigmaFrame e = new EnigmaFrame();
        e.setVisible(true);
    }
}